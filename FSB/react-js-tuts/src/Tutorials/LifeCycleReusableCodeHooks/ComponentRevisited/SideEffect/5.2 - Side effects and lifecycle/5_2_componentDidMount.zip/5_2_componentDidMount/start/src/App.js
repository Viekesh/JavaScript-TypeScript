import React, {Component} from "react";
import "./index.css";
import Joke from "./Joke";

class App extends Component {
  state = {
    joke: {
      setup: "What did the client say to the server?",
      punchline: "I GET you"
    },
    isLoading: false
  };

  render() {
    return (
      <div className="container">
        <div className={this.state.isLoading ? "title title-pulse" : "title"}>
          Joke Machine
        </div>
        <Joke
          setup={this.state.joke.setup}
          punchline={this.state.joke.punchline}
        />
      </div>
    );
  }
}

export default App;
