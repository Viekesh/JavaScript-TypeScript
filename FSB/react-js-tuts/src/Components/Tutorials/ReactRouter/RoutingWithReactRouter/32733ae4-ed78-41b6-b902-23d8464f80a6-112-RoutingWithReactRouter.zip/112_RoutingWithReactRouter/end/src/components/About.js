import React from "react";
import { Col, Typography, Divider } from "antd";
const { Title } = Typography;

const About = () => {
  return (
    <Col span={24}>
      <Title>About</Title>
      <Divider />
      <p>
        Lorem ipsum dolor sit amet, autem minim ut cum. An vix exerci veritus
        recusabo, per fastidii adipisci expetendis at. Eam quot decore persecuti
        cu, ut est utinam vidisse saperet, ne illum tincidunt qui. Eam te congue
        utamur tibique, dolorum scaevola mediocritatem eu eam, appetere
        tacimates te qui. Ex aliquip accommodare definitiones qui. Quis legere
        iriure vis cu, at cum copiosae perpetua contentiones. Utinam corrumpit
        te per, illud quaeque honestatis ea mea. Mel et solet dicant interesset,
        inani mandamus adversarium ea quo. Impetus persius usu ad, sit at magna
        omnium prodesset. Pri ut noster oportere. Summo persequeris eum eu, esse
        populo percipitur vix ex, ipsum facer putant ea sit. Ei etiam impetus
        vix, soluta conceptam dissentiet vel te. Id dolore soleat expetendis
        mea, duis sale molestiae eu duo. Fierent offendit pri ei. Munere
        legendos theophrastus eum ne. Assum inermis interesset mea ei. Cum at
        officiis iudicabit voluptatum, in qui putent nostrud, per et ignota
        maiestatis. Ne sea eripuit tibique, at assueverit liberavisse per. Cu
        vel vocibus graecis repudiandae, vel id stet tibique praesent, ea has
        modus reprimique. Sed at ornatus facilisi suscipiantur. Suavitate
        consectetuer no vix, ponderum oporteat an pro. Ex iriure electram
        mediocritatem vim, mea idque iudicabit eu, sea no feugiat evertitur
        repudiandae. No enim dolor has. Deserunt intellegat mel at, assueverit
        reprehendunt id vim. Duo summo oblique ad, eos populo aliquam evertitur
        ei, nec malis etiam dolor ut. Eos in amet mollis civibus, case vivendo
        eum eu, ei qui utinam alterum. Id harum verterem efficiantur eos, ex sed
        utinam recusabo similique. Minim graeco viderer vel ei, est aeterno
        adversarium no. Dicat audiam tincidunt te nam, falli equidem habemus pri
        et. Vocibus facilis ad cum, qui ei lobortis pertinacia. Has ad labore
        moderatius, pri no ridens molestiae dignissim, ei dicat melius indoctum
        pri. Eum possit euripidis an, an mei fuisset scaevola disputando. Cum ea
        nominavi tincidunt, mel in alia appetere, disputando referrentur vix ne.
        Pri ad dolores convenire. Qui eros discere noluisse cu. Lorem zril te
        eum. At nam graecis lobortis. Ad dicant posidonium interesset sea, assum
        albucius reprehendunt an mea, id quodsi delicata qui. In vel dignissim
        suscipiantur. Mel etiam fabulas ad. An pro eius inani adipisci, epicuri
        erroribus mei ne, mandamus suavitate mei ex. Vim elit elaboraret in. Ius
        cibo dicta deterruisset ut. No viris menandri indoctum sit, nihil
        ancillae consequuntur an his, at homero vivendum mea. His appellantur
        delicatissimi cu. Movet libris disputationi qui ne. Populo aliquando ea
        per. Ex has probatus deseruisse. Dicant nusquam consetetur cu qui. Duo
        ut hinc praesent, cu choro tation civibus mei. Aeque movet mei eu, vim
        tota prompta ea. Prima solum antiopam duo te, et eum accusata imperdiet
        efficiendi. Te pro sint nullam graeci, cum ad erat noluisse, simul
        cetero appetere has cu. Sea no eruditi indoctum, duo vide dolore
        elaboraret an. Ne novum tractatos nam, laudem alienum his ex. Ad facer
        oratio vulputate sea.
        <br />
        <br />
        Lorem ipsum dolor sit amet, autem minim ut cum. An vix exerci veritus
        recusabo, per fastidii adipisci expetendis at. Eam quot decore persecuti
        cu, ut est utinam vidisse saperet, ne illum tincidunt qui. Eam te congue
        utamur tibique, dolorum scaevola mediocritatem eu eam, appetere
        tacimates te qui. Ex aliquip accommodare definitiones qui. Quis legere
        iriure vis cu, at cum copiosae perpetua contentiones. Utinam corrumpit
        te per, illud quaeque honestatis ea mea. Mel et solet dicant interesset,
        inani mandamus adversarium ea quo. Impetus persius usu ad, sit at magna
        omnium prodesset. Pri ut noster oportere. Summo persequeris eum eu, esse
        populo percipitur vix ex, ipsum facer putant ea sit. Ei etiam impetus
        vix, soluta conceptam dissentiet vel te. Id dolore soleat expetendis
        mea, duis sale molestiae eu duo. Fierent offendit pri ei. Munere
        legendos theophrastus eum ne. Assum inermis interesset mea ei. Cum at
        officiis iudicabit voluptatum, in qui putent nostrud, per et ignota
        maiestatis. Ne sea eripuit tibique, at assueverit liberavisse per. Cu
        vel vocibus graecis repudiandae, vel id stet tibique praesent, ea has
        modus reprimique. Sed at ornatus facilisi suscipiantur. Suavitate
        consectetuer no vix, ponderum oporteat an pro. Ex iriure electram
        mediocritatem vim, mea idque iudicabit eu, sea no feugiat evertitur
        repudiandae. No enim dolor has. Deserunt intellegat mel at, assueverit
        reprehendunt id vim. Duo summo oblique ad, eos populo aliquam evertitur
        ei, nec malis etiam dolor ut. Eos in amet mollis civibus, case vivendo
        eum eu, ei qui utinam alterum. Id harum verterem efficiantur eos, ex sed
        utinam recusabo similique. Minim graeco viderer vel ei, est aeterno
        adversarium no. Dicat audiam tincidunt te nam, falli equidem habemus pri
        et. Vocibus facilis ad cum, qui ei lobortis pertinacia. Has ad labore
        moderatius, pri no ridens molestiae dignissim, ei dicat melius indoctum
        pri. Eum possit euripidis an, an mei fuisset scaevola disputando. Cum ea
        nominavi tincidunt, mel in alia appetere, disputando referrentur vix ne.
        Pri ad dolores convenire. Qui eros discere noluisse cu. Lorem zril te
        eum. At nam graecis lobortis. Ad dicant posidonium interesset sea, assum
        albucius reprehendunt an mea, id quodsi delicata qui. In vel dignissim
        suscipiantur. Mel etiam fabulas ad. An pro eius inani adipisci, epicuri
        erroribus mei ne, mandamus suavitate mei ex. Vim elit elaboraret in. Ius
        cibo dicta deterruisset ut. No viris menandri indoctum sit, nihil
        ancillae consequuntur an his, at homero vivendum mea. His appellantur
        delicatissimi cu. Movet libris disputationi qui ne. Populo aliquando ea
        per. Ex has probatus deseruisse. Dicant nusquam consetetur cu qui. Duo
        ut hinc praesent, cu choro tation civibus mei. Aeque movet mei eu, vim
        tota prompta ea. Prima solum antiopam duo te, et eum accusata imperdiet
        efficiendi. Te pro sint nullam graeci, cum ad erat noluisse, simul
        cetero appetere has cu. Sea no eruditi indoctum, duo vide dolore
        elaboraret an. Ne novum tractatos nam, laudem alienum his ex. Ad facer
        oratio vulputate sea.
      </p>
    </Col>
  );
};

export default About;
