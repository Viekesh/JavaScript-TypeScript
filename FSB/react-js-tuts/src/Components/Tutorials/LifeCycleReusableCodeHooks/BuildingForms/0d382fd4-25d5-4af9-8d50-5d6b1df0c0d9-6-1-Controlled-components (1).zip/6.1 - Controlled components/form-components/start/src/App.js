import React from 'react';
import MessageBox from './MessageBox';

const App = () => <MessageBox />;

export default App;
