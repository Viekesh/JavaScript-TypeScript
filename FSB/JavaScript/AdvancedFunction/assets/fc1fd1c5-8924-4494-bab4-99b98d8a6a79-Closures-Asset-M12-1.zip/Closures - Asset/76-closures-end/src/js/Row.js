export default (unit, value) => `<div class="conversion">
<div class="unit">${unit}</div>
<div class="value">${value}</div>
</div>`;
