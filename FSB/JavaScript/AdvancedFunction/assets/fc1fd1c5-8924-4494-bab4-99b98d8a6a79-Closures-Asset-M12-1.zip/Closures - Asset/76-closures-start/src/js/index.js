import Row from './Row';

const outputDiv = document.querySelector('#output');
const inputEl = document.querySelector("input[name='inputTemp']");
